# 00 사건 시작

claim-suite로 새 사건을 시작해 줘.
- 목적: (침해 / 무효·진보성 / FTO·회피 / 해석 중 하나)
- 관할: (미국 / 한국 / 둘 다)
- 특허·청구항·우선일: 
- 대상(제품명·버전 또는 선행문헌): 
cases/example(FTO) 또는 cases/invalidity-example(무효·진보성)을 복사해 사건 폴더를 만들고 case.json을 채운 뒤, suite_status로 다음 할 일을 알려 줘. 분석 결론은 아직 내지 마.
